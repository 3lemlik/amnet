/* AM Print — برنامج صغير يشتغل على حاسوب المطعم (كاشير أو مطبخ)
   - يكتشف الطابعات: طابعات الشبكة (منفذ 9100) + طابعات الويندوز (USB)
   - يستلم الوصل من موقع AM RESTO ويطبعه مباشرة (ESC/POS) بدون أي نافذة
   ما يحتاج npm install. بس Node.js 18 أو أحدث. */
"use strict";
const http=require("http"),net=require("net"),os=require("os"),fs=require("fs"),path=require("path"),{execFile}=require("child_process");
const V="1.0.0",PORT=+process.env.AMP_PORT||9123,DIR=__dirname;
let CFG={origins:["https://3lemlik.github.io","http://localhost","http://127.0.0.1"]};
try{Object.assign(CFG,JSON.parse(fs.readFileSync(path.join(DIR,"config.json"),"utf8")))}catch(e){}
const LOG=[];const log=(...a)=>{const l=new Date().toLocaleTimeString("en-GB")+"  "+a.join(" ");LOG.unshift(l);LOG.length=Math.min(LOG.length,60);console.log(l)};
const okOrigin=o=>!o||CFG.origins.some(x=>o===x||o.startsWith(x+":")||o.startsWith(x+"/"));
/* ---------- اكتشاف طابعات الشبكة ---------- */
function probe(ip,port,ms){return new Promise(res=>{const s=net.connect({host:ip,port});let done=false;const fin=v=>{if(done)return;done=true;s.destroy();res(v)};s.setTimeout(ms,()=>fin(false));s.on("connect",()=>fin(true));s.on("error",()=>fin(false))})}
let NETC={t:0,l:[]};
async function scanNet(){const me=[],subs=new Set();for(const l of Object.values(os.networkInterfaces()))for(const a of l||[])if(a.family==="IPv4"&&!a.internal&&!/^169\.254\./.test(a.address)){me.push(a.address);subs.add(a.address.split(".").slice(0,3).join("."))}
  const ips=[];subs.forEach(s=>{for(let i=1;i<255;i++){const ip=s+"."+i;ips.push(ip)}});const found=[];let k=0;
  const extra=(CFG.ports||[]).map(Number).filter(Boolean);
  async function worker(){while(k<ips.length){const ip=ips[k++];if(await probe(ip,9100,400))found.push({ip,port:9100,self:me.includes(ip)});for(const p of extra)if(await probe(ip,p,300))found.push({ip,port:p})}}
  await Promise.all(Array.from({length:96},worker));found.sort((a,b)=>+a.ip.split(".")[3]-+b.ip.split(".")[3]);NETC={t:Date.now(),l:found};log("scan:",found.length,"network printer(s) on",[...subs].join(", ")||"no network");return found}
/* ---------- طابعات الويندوز ---------- */
function ps(args,ms){return new Promise((res,rej)=>{execFile("powershell.exe",["-NoProfile","-NonInteractive","-ExecutionPolicy","Bypass",...args],{windowsHide:true,timeout:ms||30000,maxBuffer:4<<20},(e,out,err)=>{if(e)rej(new Error((String(err||"").trim()||e.message).slice(0,300)));else res(String(out))})})}
async function listWin(){if(process.platform!=="win32")return[];try{const o=await ps(["-Command","[Console]::OutputEncoding=[Text.Encoding]::UTF8;Get-CimInstance Win32_Printer | Select-Object Name,PortName,Default,WorkOffline,DriverName | ConvertTo-Json -Compress"]);let j=JSON.parse(o.trim()||"[]");if(!Array.isArray(j))j=[j];return j.map(p=>({name:p.Name,port:p.PortName,def:!!p.Default,off:!!p.WorkOffline,drv:p.DriverName}))}catch(e){log("printers list failed:",e.message);return[]}}
/* ---------- الطبع ---------- */
function printNet(ip,port,buf){return new Promise((res,rej)=>{const s=net.connect({host:ip,port:port||9100});let ok=false;s.setTimeout(10000,()=>{s.destroy();rej(new Error("ETIMEDOUT printer "+ip))});
  s.on("connect",()=>{s.end(buf,()=>{ok=true})});s.on("close",()=>{if(ok)res();});s.on("error",e=>rej(new Error(e.code+" "+ip)));s.on("finish",()=>{ok=true;setTimeout(()=>{s.destroy();res()},300)})})}
async function printWin(name,buf){if(process.platform!=="win32")throw new Error("windows printer on non-windows");const f=path.join(os.tmpdir(),"amprint_"+Date.now()+"_"+Math.random().toString(36).slice(2)+".bin");fs.writeFileSync(f,buf);
  try{const o=await ps(["-File",path.join(DIR,"raw.ps1"),"-Printer",name,"-Path",f],45000);if(!/OK/.test(o))throw new Error("spooler: "+o.trim().slice(0,200))}finally{try{fs.unlinkSync(f)}catch(e){}}}
const QS=new Map();
function enqueue(key,fn){const p=(QS.get(key)||Promise.resolve()).then(fn,fn);QS.set(key,p.catch(()=>{}));return p}
/* ---------- HTTP ---------- */
function send(res,code,obj,origin){const h={"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"};if(origin){h["Access-Control-Allow-Origin"]=origin;h["Vary"]="Origin"}res.writeHead(code,h);res.end(JSON.stringify(obj))}
const srv=http.createServer((req,res)=>{const origin=req.headers.origin;
  if(origin&&!okOrigin(origin)){log("blocked origin:",origin);return send(res,403,{err:"origin not allowed"})}
  if(req.method==="OPTIONS"){res.writeHead(204,{"Access-Control-Allow-Origin":origin||"*","Access-Control-Allow-Methods":"GET,POST,OPTIONS","Access-Control-Allow-Headers":"Content-Type","Access-Control-Allow-Private-Network":"true","Access-Control-Max-Age":"600","Vary":"Origin"});return res.end()}
  const u=new URL(req.url,"http://x");
  if(req.method==="GET"&&u.pathname==="/ping")return send(res,200,{ok:true,v:V,host:os.hostname(),os:process.platform},origin);
  if(req.method==="GET"&&u.pathname==="/printers"){(async()=>{const [win,netl]=await Promise.all([listWin(),u.searchParams.get("scan")?scanNet():Promise.resolve(NETC.l)]);send(res,200,{win,net:netl.filter(x=>!x.self||process.env.AMP_SELF)},origin)})().catch(e=>send(res,500,{err:e.message},origin));return}
  if(req.method==="POST"&&u.pathname==="/print"){let b=[],n=0;req.on("data",c=>{n+=c.length;if(n>8e6){req.destroy();return}b.push(c)});req.on("end",async()=>{try{const j=JSON.parse(Buffer.concat(b).toString("utf8"));const buf=Buffer.from(j.b64||"","base64");const to=j.to||{};if(!buf.length)throw new Error("empty");
      const key=to.t==="net"?"n:"+to.ip+":"+(to.port||9100):"w:"+to.name;const t0=Date.now();
      await enqueue(key,()=>to.t==="net"?printNet(to.ip,to.port,buf):to.t==="win"?printWin(to.name,buf):Promise.reject(new Error("bad target")));
      log("printed",(buf.length/1024).toFixed(1)+"KB","->",to.t==="net"?to.ip:to.name,(Date.now()-t0)+"ms");send(res,200,{ok:true},origin)}
    catch(e){log("print failed:",e.message);send(res,200,{err:e.message},origin)}});return}
  if(req.method==="GET"&&u.pathname==="/"){res.writeHead(200,{"Content-Type":"text/html; charset=utf-8"});return res.end(`<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><meta http-equiv="refresh" content="5"><title>AM Print</title><style>body{font-family:Segoe UI,Tahoma;background:#0b0c10;color:#eceef2;padding:24px}b{color:#ff8a1f}pre{background:#121319;padding:12px;border-radius:10px;direction:ltr;text-align:left;font-size:12px;white-space:pre-wrap}</style></head><body><h2>AM <b>PRINT</b> شغّال ✓</h2><p>الإصدار ${V} · المنفذ ${PORT} · ${os.hostname()}</p><p>طابعات الشبكة اللي انلگت: ${NETC.l.map(x=>x.ip).join("، ")||"لحد الآن ماكو (افتح الإعدادات بالموقع ودوس اكتشف الطابعات)"}</p><pre>${LOG.join("\n").replace(/</g,"&lt;")||"..."}</pre><p style="color:#5d636e">تصميم وبرمجة علي مالك</p></body></html>`)}
  send(res,404,{err:"not found"},origin)});
srv.on("error",e=>{if(e.code==="EADDRINUSE"){console.log("AM Print is already running on port "+PORT);process.exit(3)}console.error(e);process.exit(1)});
srv.listen(PORT,"127.0.0.1",()=>log("AM Print "+V+" ready on http://127.0.0.1:"+PORT));
process.on("uncaughtException",e=>log("error:",e&&e.message));
