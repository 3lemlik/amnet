@echo off
title AM Print
cd /d "%~dp0"
where node >nul 2>nul || (echo. & echo  [X] Node.js is not installed. Install it from https://nodejs.org then run install.vbs again. & echo. & pause & exit /b)
:run
node server.js
if %errorlevel%==3 exit /b
echo  AM Print stopped - restarting in 5 seconds...
timeout /t 5 >nul
goto run
